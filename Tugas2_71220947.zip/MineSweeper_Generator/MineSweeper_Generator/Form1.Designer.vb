﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblBaris = New System.Windows.Forms.Label()
        Me.lblKolom = New System.Windows.Forms.Label()
        Me.lblJmlBom = New System.Windows.Forms.Label()
        Me.btnBuat = New System.Windows.Forms.Button()
        Me.nudBaris = New System.Windows.Forms.NumericUpDown()
        Me.nudKolom = New System.Windows.Forms.NumericUpDown()
        Me.nudJmlBom = New System.Windows.Forms.NumericUpDown()
        Me.Panel1 = New System.Windows.Forms.Panel()
        CType(Me.nudBaris, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudKolom, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudJmlBom, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblBaris
        '
        Me.lblBaris.AutoSize = True
        Me.lblBaris.Location = New System.Drawing.Point(12, 19)
        Me.lblBaris.Name = "lblBaris"
        Me.lblBaris.Size = New System.Drawing.Size(44, 16)
        Me.lblBaris.TabIndex = 0
        Me.lblBaris.Text = "Baris :"
        '
        'lblKolom
        '
        Me.lblKolom.AutoSize = True
        Me.lblKolom.Location = New System.Drawing.Point(12, 53)
        Me.lblKolom.Name = "lblKolom"
        Me.lblKolom.Size = New System.Drawing.Size(51, 16)
        Me.lblKolom.TabIndex = 1
        Me.lblKolom.Text = "Kolom :"
        '
        'lblJmlBom
        '
        Me.lblJmlBom.AutoSize = True
        Me.lblJmlBom.Location = New System.Drawing.Point(293, 19)
        Me.lblJmlBom.Name = "lblJmlBom"
        Me.lblJmlBom.Size = New System.Drawing.Size(95, 16)
        Me.lblJmlBom.TabIndex = 5
        Me.lblJmlBom.Text = "Jumlah Bomb :"
        '
        'btnBuat
        '
        Me.btnBuat.Location = New System.Drawing.Point(583, 17)
        Me.btnBuat.Name = "btnBuat"
        Me.btnBuat.Size = New System.Drawing.Size(75, 23)
        Me.btnBuat.TabIndex = 6
        Me.btnBuat.Text = "Buat"
        Me.btnBuat.UseVisualStyleBackColor = True
        '
        'nudBaris
        '
        Me.nudBaris.Location = New System.Drawing.Point(74, 20)
        Me.nudBaris.Name = "nudBaris"
        Me.nudBaris.Size = New System.Drawing.Size(120, 22)
        Me.nudBaris.TabIndex = 8
        '
        'nudKolom
        '
        Me.nudKolom.Location = New System.Drawing.Point(74, 51)
        Me.nudKolom.Name = "nudKolom"
        Me.nudKolom.Size = New System.Drawing.Size(120, 22)
        Me.nudKolom.TabIndex = 9
        '
        'nudJmlBom
        '
        Me.nudJmlBom.Location = New System.Drawing.Point(394, 17)
        Me.nudJmlBom.Name = "nudJmlBom"
        Me.nudJmlBom.Size = New System.Drawing.Size(120, 22)
        Me.nudJmlBom.TabIndex = 10
        '
        'Panel1
        '
        Me.Panel1.Location = New System.Drawing.Point(15, 92)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(643, 346)
        Me.Panel1.TabIndex = 11
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(687, 450)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.nudJmlBom)
        Me.Controls.Add(Me.nudKolom)
        Me.Controls.Add(Me.nudBaris)
        Me.Controls.Add(Me.btnBuat)
        Me.Controls.Add(Me.lblJmlBom)
        Me.Controls.Add(Me.lblKolom)
        Me.Controls.Add(Me.lblBaris)
        Me.Name = "Form1"
        Me.Text = "MineSweeper Generator"
        CType(Me.nudBaris, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudKolom, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudJmlBom, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblBaris As Label
    Friend WithEvents lblKolom As Label
    Friend WithEvents lblJmlBom As Label
    Friend WithEvents btnBuat As Button
    Friend WithEvents nudBaris As NumericUpDown
    Friend WithEvents nudKolom As NumericUpDown
    Friend WithEvents nudJmlBom As NumericUpDown
    Friend WithEvents Panel1 As Panel
End Class
