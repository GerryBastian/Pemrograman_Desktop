﻿Friend Class Panel1
End Class
