﻿Public Class nudJumlahTamu
    ' List untuk menyimpan data meja dan menu
    Dim mejaList As New List(Of (MejaID As Integer, Kapasitas As Integer))
    Dim menuList As New List(Of String) From {"Nasi Goreng", "Mie Goreng", "Ayam Penyet", "Sate Ayam", "Es Teh", "Es Jeruk"}

    ' Ketika form dimuat
    Private Sub nudJumlahTamu_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Menambahkan data meja ke ComboBox
        mejaList.Add((1, 2))  ' Meja 1, kapasitas 2
        mejaList.Add((2, 4))  ' Meja 2, kapasitas 4
        mejaList.Add((3, 6))  ' Meja 3, kapasitas 6
        mejaList.Add((4, 8))  ' Meja 4, kapasitas 8

        ' Mengisi ComboBox Meja dengan kapasitas meja
        For Each meja In mejaList
            cmbMeja.Items.Add($"Meja {meja.MejaID} - {meja.Kapasitas} Kursi")
        Next

        ' Set default value
        cmbMeja.SelectedIndex = 0
        lstMenu.DataSource = menuList
    End Sub

    ' Button untuk memilih meja
    Private Sub cmbMeja_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbMeja.SelectedIndexChanged
        Dim selectedMeja = cmbMeja.SelectedIndex
        If selectedMeja >= 0 Then
            Dim kapasitasMeja = mejaList(selectedMeja).Kapasitas
            ' Menyesuaikan jumlah tamu dengan kapasitas meja
            If NumericUpDown1.Value > kapasitasMeja Then
                MessageBox.Show($"Jumlah tamu melebihi kapasitas meja! Pilih meja yang memiliki kapasitas cukup.")
                NumericUpDown1.Value = kapasitasMeja
            End If
        End If
    End Sub

    ' Button Pesan untuk memproses pesanan
    Private Sub btnPesan_Click(sender As Object, e As EventArgs) Handles btnPesan.Click
        Dim selectedMeja = cmbMeja.SelectedIndex
        If selectedMeja < 0 Then
            MessageBox.Show("Pilih meja terlebih dahulu.")
            Return
        End If

        ' Ambil informasi meja dan tamu
        Dim meja = mejaList(selectedMeja)
        Dim jumlahTamu = NumericUpDown1.Value

        ' Menampilkan informasi pemesanan
        Dim pesan = $"Pesanan untuk Meja {meja.MejaID} ({meja.Kapasitas} kursi) telah diterima." & vbCrLf
        pesan &= $"Jumlah tamu: {jumlahTamu}" & vbCrLf
        pesan &= "Menu yang dipilih:" & vbCrLf

        For Each menu In lstMenu.SelectedItems
            pesan &= $"{menu}" & vbCrLf
        Next

        MessageBox.Show(pesan, "Pesanan Anda")
    End Sub

    ' Button Batal untuk membatalkan pemesanan
    Private Sub btnBatal_Click(sender As Object, e As EventArgs) Handles btnBatal.Click
        txtNama.Clear()
        NumericUpDown1.Value = 1
        cmbMeja.SelectedIndex = 0
        lstMenu.ClearSelected()
    End Sub

    Private Sub cbnomeja_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbnomeja.SelectedIndexChanged

    End Sub
End Class
