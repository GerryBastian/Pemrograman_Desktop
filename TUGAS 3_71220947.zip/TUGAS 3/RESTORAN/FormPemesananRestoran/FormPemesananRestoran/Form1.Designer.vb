﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class nudJumlahTamu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        lblNama = New Label()
        lblJumlahTamu = New Label()
        lblMeja = New Label()
        lblPesanan = New Label()
        txtNama = New TextBox()
        NumericUpDown1 = New NumericUpDown()
        cmbMeja = New ComboBox()
        lstMenu = New ListBox()
        btnPesan = New Button()
        btnBatal = New Button()
        cbnomeja = New ComboBox()
        CType(NumericUpDown1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' lblNama
        ' 
        lblNama.AutoSize = True
        lblNama.Location = New Point(26, 27)
        lblNama.Name = "lblNama"
        lblNama.Size = New Size(53, 20)
        lblNama.TabIndex = 0
        lblNama.Text = "Nama "
        ' 
        ' lblJumlahTamu
        ' 
        lblJumlahTamu.AutoSize = True
        lblJumlahTamu.Location = New Point(26, 80)
        lblJumlahTamu.Name = "lblJumlahTamu"
        lblJumlahTamu.Size = New Size(97, 20)
        lblJumlahTamu.TabIndex = 1
        lblJumlahTamu.Text = "Jumlah Tamu:" & vbLf
        ' 
        ' lblMeja
        ' 
        lblMeja.AutoSize = True
        lblMeja.Location = New Point(27, 136)
        lblMeja.Name = "lblMeja"
        lblMeja.Size = New Size(96, 20)
        lblMeja.TabIndex = 2
        lblMeja.Text = "Nomor Meja:"
        ' 
        ' lblPesanan
        ' 
        lblPesanan.AutoSize = True
        lblPesanan.Location = New Point(26, 186)
        lblPesanan.Name = "lblPesanan"
        lblPesanan.Size = New Size(129, 20)
        lblPesanan.TabIndex = 3
        lblPesanan.Text = "Pesanan Makanan:"
        ' 
        ' txtNama
        ' 
        txtNama.Location = New Point(198, 24)
        txtNama.Name = "txtNama"
        txtNama.PlaceholderText = "Nama Pemesan"
        txtNama.Size = New Size(125, 27)
        txtNama.TabIndex = 4
        ' 
        ' NumericUpDown1
        ' 
        NumericUpDown1.Location = New Point(198, 78)
        NumericUpDown1.Name = "NumericUpDown1"
        NumericUpDown1.Size = New Size(150, 27)
        NumericUpDown1.TabIndex = 5
        ' 
        ' cmbMeja
        ' 
        cmbMeja.FormattingEnabled = True
        cmbMeja.Location = New Point(198, 137)
        cmbMeja.Name = "cmbMeja"
        cmbMeja.Size = New Size(151, 28)
        cmbMeja.TabIndex = 6
        ' 
        ' lstMenu
        ' 
        lstMenu.FormattingEnabled = True
        lstMenu.Location = New Point(586, 80)
        lstMenu.Name = "lstMenu"
        lstMenu.SelectionMode = SelectionMode.MultiSimple
        lstMenu.Size = New Size(150, 104)
        lstMenu.TabIndex = 7
        ' 
        ' btnPesan
        ' 
        btnPesan.Location = New Point(462, 81)
        btnPesan.Name = "btnPesan"
        btnPesan.Size = New Size(94, 29)
        btnPesan.TabIndex = 8
        btnPesan.Text = "Pesan"
        btnPesan.UseVisualStyleBackColor = True
        ' 
        ' btnBatal
        ' 
        btnBatal.Location = New Point(462, 136)
        btnBatal.Name = "btnBatal"
        btnBatal.Size = New Size(94, 29)
        btnBatal.TabIndex = 9
        btnBatal.Text = "Batal"
        btnBatal.UseVisualStyleBackColor = True
        ' 
        ' cbnomeja
        ' 
        cbnomeja.FormattingEnabled = True
        cbnomeja.Location = New Point(198, 186)
        cbnomeja.Name = "cbnomeja"
        cbnomeja.Size = New Size(151, 28)
        cbnomeja.TabIndex = 12
        ' 
        ' nudJumlahTamu
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(cbnomeja)
        Controls.Add(btnBatal)
        Controls.Add(btnPesan)
        Controls.Add(lstMenu)
        Controls.Add(cmbMeja)
        Controls.Add(NumericUpDown1)
        Controls.Add(txtNama)
        Controls.Add(lblPesanan)
        Controls.Add(lblMeja)
        Controls.Add(lblJumlahTamu)
        Controls.Add(lblNama)
        Name = "nudJumlahTamu"
        Text = "Form1"
        CType(NumericUpDown1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents lblNama As Label
    Friend WithEvents lblJumlahTamu As Label
    Friend WithEvents lblMeja As Label
    Friend WithEvents lblPesanan As Label
    Friend WithEvents txtNama As TextBox
    Friend WithEvents NumericUpDown1 As NumericUpDown
    Friend WithEvents cmbMeja As ComboBox
    Friend WithEvents lstMenu As ListBox
    Friend WithEvents btnPesan As Button
    Friend WithEvents btnBatal As Button
    Friend WithEvents cbnomeja As ComboBox

End Class
