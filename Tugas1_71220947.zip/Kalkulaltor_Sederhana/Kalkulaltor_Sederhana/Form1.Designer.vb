﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.txtInput = New System.Windows.Forms.TextBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.cmdC = New System.Windows.Forms.Button()
        Me.CmdEqual = New System.Windows.Forms.Button()
        Me.CmdAddition = New System.Windows.Forms.Button()
        Me.CmdSqrt = New System.Windows.Forms.Button()
        Me.CmdMultiply = New System.Windows.Forms.Button()
        Me.CmdInverse = New System.Windows.Forms.Button()
        Me.CmdSubtract = New System.Windows.Forms.Button()
        Me.CmdPowerOf = New System.Windows.Forms.Button()
        Me.CmdDivision = New System.Windows.Forms.Button()
        Me.Cmd9 = New System.Windows.Forms.Button()
        Me.Cmd8 = New System.Windows.Forms.Button()
        Me.CmdDecimal = New System.Windows.Forms.Button()
        Me.Cmd3 = New System.Windows.Forms.Button()
        Me.CmdSign = New System.Windows.Forms.Button()
        Me.Cmd6 = New System.Windows.Forms.Button()
        Me.Cmd0 = New System.Windows.Forms.Button()
        Me.Cmd2 = New System.Windows.Forms.Button()
        Me.Cmd1 = New System.Windows.Forms.Button()
        Me.Cmd5 = New System.Windows.Forms.Button()
        Me.Cmd4 = New System.Windows.Forms.Button()
        Me.Cmd7 = New System.Windows.Forms.Button()
        Me.cmdCE = New System.Windows.Forms.Button()
        Me.cmdBackspace = New System.Windows.Forms.Button()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.txtInput)
        Me.Panel1.Location = New System.Drawing.Point(44, 40)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(403, 121)
        Me.Panel1.TabIndex = 0
        '
        'txtInput
        '
        Me.txtInput.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtInput.Location = New System.Drawing.Point(18, 28)
        Me.txtInput.Multiline = True
        Me.txtInput.Name = "txtInput"
        Me.txtInput.Size = New System.Drawing.Size(339, 58)
        Me.txtInput.TabIndex = 0
        Me.txtInput.Text = "0"
        Me.txtInput.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtInput.UseWaitCursor = True
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.cmdC)
        Me.Panel2.Controls.Add(Me.CmdEqual)
        Me.Panel2.Controls.Add(Me.CmdAddition)
        Me.Panel2.Controls.Add(Me.CmdSqrt)
        Me.Panel2.Controls.Add(Me.CmdMultiply)
        Me.Panel2.Controls.Add(Me.CmdInverse)
        Me.Panel2.Controls.Add(Me.CmdSubtract)
        Me.Panel2.Controls.Add(Me.CmdPowerOf)
        Me.Panel2.Controls.Add(Me.CmdDivision)
        Me.Panel2.Controls.Add(Me.Cmd9)
        Me.Panel2.Controls.Add(Me.Cmd8)
        Me.Panel2.Controls.Add(Me.CmdDecimal)
        Me.Panel2.Controls.Add(Me.Cmd3)
        Me.Panel2.Controls.Add(Me.CmdSign)
        Me.Panel2.Controls.Add(Me.Cmd6)
        Me.Panel2.Controls.Add(Me.Cmd0)
        Me.Panel2.Controls.Add(Me.Cmd2)
        Me.Panel2.Controls.Add(Me.Cmd1)
        Me.Panel2.Controls.Add(Me.Cmd5)
        Me.Panel2.Controls.Add(Me.Cmd4)
        Me.Panel2.Controls.Add(Me.Cmd7)
        Me.Panel2.Controls.Add(Me.cmdCE)
        Me.Panel2.Controls.Add(Me.cmdBackspace)
        Me.Panel2.Location = New System.Drawing.Point(44, 183)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(399, 400)
        Me.Panel2.TabIndex = 1
        '
        'cmdC
        '
        Me.cmdC.Location = New System.Drawing.Point(305, 14)
        Me.cmdC.Name = "cmdC"
        Me.cmdC.Size = New System.Drawing.Size(52, 56)
        Me.cmdC.TabIndex = 1
        Me.cmdC.Text = "C"
        Me.cmdC.UseVisualStyleBackColor = True
        '
        'CmdEqual
        '
        Me.CmdEqual.Location = New System.Drawing.Point(305, 318)
        Me.CmdEqual.Name = "CmdEqual"
        Me.CmdEqual.Size = New System.Drawing.Size(52, 57)
        Me.CmdEqual.TabIndex = 1
        Me.CmdEqual.Text = "="
        Me.CmdEqual.UseVisualStyleBackColor = True
        '
        'CmdAddition
        '
        Me.CmdAddition.Location = New System.Drawing.Point(247, 318)
        Me.CmdAddition.Name = "CmdAddition"
        Me.CmdAddition.Size = New System.Drawing.Size(52, 57)
        Me.CmdAddition.TabIndex = 1
        Me.CmdAddition.Text = "+"
        Me.CmdAddition.UseVisualStyleBackColor = True
        '
        'CmdSqrt
        '
        Me.CmdSqrt.Location = New System.Drawing.Point(305, 165)
        Me.CmdSqrt.Name = "CmdSqrt"
        Me.CmdSqrt.Size = New System.Drawing.Size(78, 57)
        Me.CmdSqrt.TabIndex = 1
        Me.CmdSqrt.Text = "SQRT"
        Me.CmdSqrt.UseVisualStyleBackColor = True
        '
        'CmdMultiply
        '
        Me.CmdMultiply.Location = New System.Drawing.Point(247, 165)
        Me.CmdMultiply.Name = "CmdMultiply"
        Me.CmdMultiply.Size = New System.Drawing.Size(52, 57)
        Me.CmdMultiply.TabIndex = 1
        Me.CmdMultiply.Text = "*"
        Me.CmdMultiply.UseVisualStyleBackColor = True
        '
        'CmdInverse
        '
        Me.CmdInverse.Location = New System.Drawing.Point(305, 243)
        Me.CmdInverse.Name = "CmdInverse"
        Me.CmdInverse.Size = New System.Drawing.Size(52, 57)
        Me.CmdInverse.TabIndex = 1
        Me.CmdInverse.Text = "1/x"
        Me.CmdInverse.UseVisualStyleBackColor = True
        '
        'CmdSubtract
        '
        Me.CmdSubtract.Location = New System.Drawing.Point(247, 243)
        Me.CmdSubtract.Name = "CmdSubtract"
        Me.CmdSubtract.Size = New System.Drawing.Size(52, 57)
        Me.CmdSubtract.TabIndex = 1
        Me.CmdSubtract.Text = "-"
        Me.CmdSubtract.UseVisualStyleBackColor = True
        '
        'CmdPowerOf
        '
        Me.CmdPowerOf.Location = New System.Drawing.Point(305, 87)
        Me.CmdPowerOf.Name = "CmdPowerOf"
        Me.CmdPowerOf.Size = New System.Drawing.Size(52, 57)
        Me.CmdPowerOf.TabIndex = 1
        Me.CmdPowerOf.Text = "X^"
        Me.CmdPowerOf.UseVisualStyleBackColor = True
        '
        'CmdDivision
        '
        Me.CmdDivision.Location = New System.Drawing.Point(247, 87)
        Me.CmdDivision.Name = "CmdDivision"
        Me.CmdDivision.Size = New System.Drawing.Size(52, 57)
        Me.CmdDivision.TabIndex = 1
        Me.CmdDivision.Text = "/"
        Me.CmdDivision.UseVisualStyleBackColor = True
        '
        'Cmd9
        '
        Me.Cmd9.Location = New System.Drawing.Point(158, 87)
        Me.Cmd9.Name = "Cmd9"
        Me.Cmd9.Size = New System.Drawing.Size(52, 57)
        Me.Cmd9.TabIndex = 1
        Me.Cmd9.Text = "9"
        Me.Cmd9.UseVisualStyleBackColor = True
        '
        'Cmd8
        '
        Me.Cmd8.Location = New System.Drawing.Point(87, 87)
        Me.Cmd8.Name = "Cmd8"
        Me.Cmd8.Size = New System.Drawing.Size(52, 57)
        Me.Cmd8.TabIndex = 1
        Me.Cmd8.Text = "8"
        Me.Cmd8.UseVisualStyleBackColor = True
        '
        'CmdDecimal
        '
        Me.CmdDecimal.Location = New System.Drawing.Point(158, 318)
        Me.CmdDecimal.Name = "CmdDecimal"
        Me.CmdDecimal.Size = New System.Drawing.Size(52, 57)
        Me.CmdDecimal.TabIndex = 1
        Me.CmdDecimal.Text = "."
        Me.CmdDecimal.UseVisualStyleBackColor = True
        '
        'Cmd3
        '
        Me.Cmd3.Location = New System.Drawing.Point(158, 243)
        Me.Cmd3.Name = "Cmd3"
        Me.Cmd3.Size = New System.Drawing.Size(52, 57)
        Me.Cmd3.TabIndex = 1
        Me.Cmd3.Text = "3"
        Me.Cmd3.UseVisualStyleBackColor = True
        '
        'CmdSign
        '
        Me.CmdSign.Location = New System.Drawing.Point(87, 318)
        Me.CmdSign.Name = "CmdSign"
        Me.CmdSign.Size = New System.Drawing.Size(52, 57)
        Me.CmdSign.TabIndex = 1
        Me.CmdSign.Text = "+/-"
        Me.CmdSign.UseVisualStyleBackColor = True
        '
        'Cmd6
        '
        Me.Cmd6.Location = New System.Drawing.Point(158, 165)
        Me.Cmd6.Name = "Cmd6"
        Me.Cmd6.Size = New System.Drawing.Size(52, 57)
        Me.Cmd6.TabIndex = 1
        Me.Cmd6.Text = "6"
        Me.Cmd6.UseVisualStyleBackColor = True
        '
        'Cmd0
        '
        Me.Cmd0.Location = New System.Drawing.Point(18, 318)
        Me.Cmd0.Name = "Cmd0"
        Me.Cmd0.Size = New System.Drawing.Size(52, 57)
        Me.Cmd0.TabIndex = 1
        Me.Cmd0.Text = "0"
        Me.Cmd0.UseVisualStyleBackColor = True
        '
        'Cmd2
        '
        Me.Cmd2.Location = New System.Drawing.Point(87, 243)
        Me.Cmd2.Name = "Cmd2"
        Me.Cmd2.Size = New System.Drawing.Size(52, 57)
        Me.Cmd2.TabIndex = 1
        Me.Cmd2.Text = "2"
        Me.Cmd2.UseVisualStyleBackColor = True
        '
        'Cmd1
        '
        Me.Cmd1.Location = New System.Drawing.Point(18, 243)
        Me.Cmd1.Name = "Cmd1"
        Me.Cmd1.Size = New System.Drawing.Size(52, 57)
        Me.Cmd1.TabIndex = 1
        Me.Cmd1.Text = "1"
        Me.Cmd1.UseVisualStyleBackColor = True
        '
        'Cmd5
        '
        Me.Cmd5.Location = New System.Drawing.Point(87, 165)
        Me.Cmd5.Name = "Cmd5"
        Me.Cmd5.Size = New System.Drawing.Size(52, 57)
        Me.Cmd5.TabIndex = 1
        Me.Cmd5.Text = "5"
        Me.Cmd5.UseVisualStyleBackColor = True
        '
        'Cmd4
        '
        Me.Cmd4.Location = New System.Drawing.Point(18, 165)
        Me.Cmd4.Name = "Cmd4"
        Me.Cmd4.Size = New System.Drawing.Size(52, 57)
        Me.Cmd4.TabIndex = 1
        Me.Cmd4.Text = "4"
        Me.Cmd4.UseVisualStyleBackColor = True
        '
        'Cmd7
        '
        Me.Cmd7.Location = New System.Drawing.Point(18, 87)
        Me.Cmd7.Name = "Cmd7"
        Me.Cmd7.Size = New System.Drawing.Size(52, 57)
        Me.Cmd7.TabIndex = 1
        Me.Cmd7.Text = "7"
        Me.Cmd7.UseVisualStyleBackColor = True
        '
        'cmdCE
        '
        Me.cmdCE.Location = New System.Drawing.Point(247, 14)
        Me.cmdCE.Name = "cmdCE"
        Me.cmdCE.Size = New System.Drawing.Size(52, 57)
        Me.cmdCE.TabIndex = 1
        Me.cmdCE.Text = "CE"
        Me.cmdCE.UseVisualStyleBackColor = True
        '
        'cmdBackspace
        '
        Me.cmdBackspace.Location = New System.Drawing.Point(18, 14)
        Me.cmdBackspace.Name = "cmdBackspace"
        Me.cmdBackspace.Size = New System.Drawing.Size(121, 57)
        Me.cmdBackspace.TabIndex = 0
        Me.cmdBackspace.Text = "Backspace"
        Me.cmdBackspace.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(482, 600)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "Form1"
        Me.Text = "Calculator"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents txtInput As TextBox
    Friend WithEvents Panel2 As Panel
    Friend WithEvents cmdC As Button
    Friend WithEvents cmdCE As Button
    Friend WithEvents cmdBackspace As Button
    Friend WithEvents CmdPowerOf As Button
    Friend WithEvents CmdDivision As Button
    Friend WithEvents Cmd9 As Button
    Friend WithEvents Cmd8 As Button
    Friend WithEvents Cmd6 As Button
    Friend WithEvents Cmd5 As Button
    Friend WithEvents Cmd4 As Button
    Friend WithEvents Cmd7 As Button
    Friend WithEvents CmdEqual As Button
    Friend WithEvents CmdAddition As Button
    Friend WithEvents CmdSqrt As Button
    Friend WithEvents CmdMultiply As Button
    Friend WithEvents CmdInverse As Button
    Friend WithEvents CmdSubtract As Button
    Friend WithEvents CmdDecimal As Button
    Friend WithEvents Cmd3 As Button
    Friend WithEvents CmdSign As Button
    Friend WithEvents Cmd0 As Button
    Friend WithEvents Cmd2 As Button
    Friend WithEvents Cmd1 As Button
End Class
